export default function LogPage(){
    return <h1>로그 담을까 말까</h1>
}