// app/api/user_videos/insert/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabaseClient';

export async function POST(req: NextRequest) {
  try {
    const { json_filename } = await req.json();

    // 인증된 유저 가져오기
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();

    if (sessionError || !session) {
      return NextResponse.json({ error: '로그인이 필요합니다.' }, { status: 401 });
    }

    const user_id = session.user.id;

    // user_videos 테이블에 새로운 작업 추가
    const { error: insertError } = await supabase.from('user_videos').insert({
      user_id,
      status: 'processing',
      json_filename: json_filename || null,
    });

    if (insertError) {
      return NextResponse.json({ error: insertError.message }, { status: 500 });
    }

    return NextResponse.json({ message: '🎬 영상 작업 기록이 저장되었습니다.' });
  } catch (error: any) {
    console.error('Insert user_video error:', error.message);
    return NextResponse.json({ error: '서버 에러 발생' }, { status: 500 });
  }
}
